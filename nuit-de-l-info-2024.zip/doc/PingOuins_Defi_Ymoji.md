# Défi Ymoji - Shigetaka Kurita n’a qu’à bien se tenir 

## Équipe Ping-ouins

## Explication des choix faits :
*La tête de page*  
Nous avons décidé de mettre en place un menu composé uniquement d’émojis.  
Sur notre site nous pouvons voir dans la tête de page, notre logo sur la gauche, ainsi que les différents boutons de navigation sur la droite.  
Cette approche est pertinente car elle permet de simplifier la tête de page en réduisant au minimum le nombre de textes utilisés.

*Les boutons*  
Nous avons également repris le même principe pour les boutons. Ces derniers ne contiennent pas de texte mais des émojis. 